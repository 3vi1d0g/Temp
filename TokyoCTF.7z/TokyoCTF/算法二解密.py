for i in range(48,125):
	if i<=0x40 or i>0x5a:
		if i<=0x60 or i>0x7a:
			print chr(i)+"----"+chr(i)
		else:
			print chr(i)+"----"+chr((i-84)%26+97)
	else:
		print chr(i)+"----"+chr((i-52)%26+65)